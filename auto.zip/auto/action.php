<?php
require_once 'config.php';

if (isset($_POST['query'])) {
    $inpText = '%' . $_POST['query'] . '%';

    // Initially, the query will retrieve records based on any matching field
    $sql = "SELECT * FROM members WHERE first_name LIKE ? OR last_name LIKE ? OR majors LIKE ? OR subgroup LIKE ?";
    
    // Adjust the query based on the available input fields
    if (isset($_POST['first_name'])) {
        $sql = "SELECT * FROM members WHERE first_name LIKE ?";
    } elseif (isset($_POST['last_name'])) {
        $sql = "SELECT * FROM members WHERE last_name LIKE ?";
    } elseif (isset($_POST['majors'])) {
        $sql = "SELECT * FROM members WHERE majors LIKE ?";
    } elseif (isset($_POST['subgroup'])) {
        $sql = "SELECT * FROM members WHERE subgroup LIKE ?";
    }

    $stmt = $conn->prepare($sql);

    if (isset($_POST['first_name']) || isset($_POST['last_name']) || isset($_POST['majors']) || isset($_POST['subgroup'])) {
        $stmt->bind_param("s", $inpText);
    } else {
        // If no specific field is provided, use the initial query
        $stmt->bind_param("ssss", $inpText, $inpText, $inpText, $inpText);
    }

    $stmt->execute();
    $result = $stmt->get_result();

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            echo '<a href="#" class="list-group-item list-group-item-action border-1">' . $row['first_name'] . $row['last_name'] . $row['majors'] . $row['subgroup'] . '</a>';
        }
    } else {
        echo '<p class="list-group-item border-1">No Record</p>';
    }
}
?>
