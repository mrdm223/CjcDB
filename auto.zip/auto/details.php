<?php
require_once 'config.php';

if (isset($_POST['submit'])) {
    $first_name = isset($_POST['first_name']) ? $_POST['first_name'] : '';
    $last_name = isset($_POST['last_name']) ? $_POST['last_name'] : '';
    $majors = isset($_POST['majors']) ? $_POST['majors'] : '';
    $subgroup = isset($_POST['subgroup']) ? $_POST['subgroup'] : '';

    // Add this debugging code to check the values
    echo "First Name: $first_name<br>";
    echo "Last Name: $last_name<br>";
    echo "Majors: $majors<br>";
    echo "Subgroup: $subgroup<br>";

    $sql = "SELECT * FROM members WHERE first_name = $first_name AND last_name = $last_name AND majors = $majors AND subgroup = $subgroup";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        echo "Error in preparing statement: " . $conn->error;
        exit();
    }

    $stmt->bindParam(':first_name', $first_name);
    $stmt->bindParam(':last_name', $last_name);
    $stmt->bindParam(':majors', $majors);
    $stmt->bindParam(':subgroup', $subgroup);

    $result = $stmt->execute();

    if (!$result) {
        echo "Error in executing statement: " . $stmt->error;
        exit();
    }

    $row = $stmt->fetch();

    if (!$row) {
        echo "Record not found.";
        exit();
    }
} else {
    header('location: .');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Details</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.1/css/bootstrap.min.css">
</head>

<body>
  <div class="container">
    <div class="row mt-5">
      <div class="col-5 mx-auto">
        <div class="card shadow text-center">
          <div class="card-header">
            <h1><?= $row['first_name'] ?></h1>
          </div>
          <div class="card-body">
            <h4><b>Last name :</b> <?= $row['last_name'] ?></h4>
            <h4><b>Majors :</b> <?= $row['majors'] ?></h4>
            <h4><b>Subgroup ID :</b> <?= $row['subgroup'] ?></h4>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>

</html>
